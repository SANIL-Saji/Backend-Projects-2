const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const controller = require('../controllers/projectController');

router.post('/:teamId/projects', auth, controller.createProject);
router.get('/:teamId/projects', auth, controller.getProjectsByTeam);

module.exports = router;
