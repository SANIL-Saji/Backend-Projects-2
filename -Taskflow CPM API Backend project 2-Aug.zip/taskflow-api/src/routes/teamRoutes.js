const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const teamController = require('../controllers/teamController');

router.post('/', auth, teamController.createTeam);

module.exports = router;
