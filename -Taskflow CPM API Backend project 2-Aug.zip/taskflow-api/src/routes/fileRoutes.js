const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const upload = require('../middlewares/uploadMiddleware');
const controller = require('../controllers/fileController');

router.post(
  '/tasks/:taskId/files',
  auth,
  upload.single('file'),
  controller.uploadFile
);

module.exports = router;
