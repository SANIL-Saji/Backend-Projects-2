const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const controller = require('../controllers/taskController');

router.post('/projects/:projectId/tasks', auth, controller.createTask);
router.post('/tasks/:taskId/dependencies', auth, controller.addDependency);
router.patch('/tasks/:taskId/status', auth, controller.updateStatus);

module.exports = router;
