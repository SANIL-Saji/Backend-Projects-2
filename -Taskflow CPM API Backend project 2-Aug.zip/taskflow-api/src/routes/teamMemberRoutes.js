const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const controller = require('../controllers/teamMemberController');

router.post('/:teamId/members', auth, controller.addMember);
router.get('/:teamId/members', auth, controller.getMembers);

module.exports = router;
