const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const controller = require('../controllers/commentController');

router.post('/tasks/:taskId/comments', auth, controller.addComment);
router.get('/tasks/:taskId/comments', auth, controller.getCommentsByTask);

module.exports = router;
