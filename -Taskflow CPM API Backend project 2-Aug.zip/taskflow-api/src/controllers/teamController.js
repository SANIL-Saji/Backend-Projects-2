const pool = require('../config/db');

exports.createTeam = async (req, res) => {
  const { name } = req.body;

  if (!name)
    return res.status(400).json({ message: 'Team name required' });

  try {
    const [result] = await pool.query(
      'INSERT INTO teams (name) VALUES (?)',
      [name]
    );

    // creator becomes admin
    await pool.query(
      'INSERT INTO team_members (team_id, user_id, role) VALUES (?, ?, ?)',
      [result.insertId, req.user.id, 'admin']
    );

    res.status(201).json({
      message: 'Team created',
      teamId: result.insertId
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
