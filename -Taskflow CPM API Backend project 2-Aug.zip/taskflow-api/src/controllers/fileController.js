const pool = require('../config/db');

exports.uploadFile = async (req, res) => {
  const { taskId } = req.params;

  if (!req.file)
    return res.status(400).json({ message: 'No file uploaded' });

  try {
    await pool.query(
      `INSERT INTO files (task_id, user_id, filename, filepath)
       VALUES (?, ?, ?, ?)`,
      [
        taskId,
        req.user.id,
        req.file.originalname,
        req.file.path
      ]
    );

    res.status(201).json({ message: 'File uploaded' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
