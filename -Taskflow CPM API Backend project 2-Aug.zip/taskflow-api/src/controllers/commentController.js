const pool = require('../config/db');

/**
 * Add a comment to a task (supports threaded replies)
 */
exports.addComment = async (req, res) => {
  const { taskId } = req.params;
  const { content, parent_comment_id } = req.body;

  if (!content)
    return res.status(400).json({ message: 'Comment content required' });

  try {
    const [result] = await pool.query(
      `INSERT INTO comments (task_id, user_id, parent_comment_id, content)
       VALUES (?, ?, ?, ?)`,
      [
        taskId,
        req.user.id,
        parent_comment_id || null,
        content
      ]
    );

    res.status(201).json({
      message: 'Comment added',
      commentId: result.insertId
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/**
 * Get comments for a task (flat list, frontend can nest)
 */
exports.getCommentsByTask = async (req, res) => {
  const { taskId } = req.params;

  try {
    const [comments] = await pool.query(
      `SELECT c.id, c.content, c.parent_comment_id, c.created_at,
              u.id AS user_id, u.name
       FROM comments c
       JOIN users u ON u.id = c.user_id
       WHERE c.task_id = ?
       ORDER BY c.created_at`,
      [taskId]
    );

    res.json(comments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
