const pool = require('../config/db');

/**
 * Create a task
 */
exports.createTask = async (req, res) => {
  const { projectId } = req.params;
  const { title, description, priority, due_date, assignees } = req.body;

  if (!title)
    return res.status(400).json({ message: 'Task title required' });

  try {
    const [result] = await pool.query(
      `INSERT INTO tasks 
       (project_id, title, description, priority, due_date)
       VALUES (?, ?, ?, ?, ?)`,
      [
        projectId,
        title,
        description || null,
        priority || 'medium',
        due_date || null
      ]
    );

    // Assign users (multiple assignees)
    if (Array.isArray(assignees)) {
      for (const userId of assignees) {
        await pool.query(
          'INSERT INTO task_assignees (task_id, user_id) VALUES (?, ?)',
          [result.insertId, userId]
        );
      }
    }

    res.status(201).json({
      message: 'Task created',
      taskId: result.insertId
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/**
 * Add dependency between tasks
 */
exports.addDependency = async (req, res) => {
  const { taskId } = req.params;
  const { depends_on_task_id } = req.body;

  try {
    await pool.query(
      'INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (?, ?)',
      [taskId, depends_on_task_id]
    );

    res.status(201).json({ message: 'Dependency added' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/**
 * Update task status (workflow)
 */
exports.updateStatus = async (req, res) => {
  const { taskId } = req.params;
  const { status } = req.body;

  const allowed = ['todo', 'in_progress', 'review', 'done'];
  if (!allowed.includes(status))
    return res.status(400).json({ message: 'Invalid status' });

  try {
    await pool.query(
      'UPDATE tasks SET status = ? WHERE id = ?',
      [status, taskId]
    );

    res.json({ message: 'Status updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
