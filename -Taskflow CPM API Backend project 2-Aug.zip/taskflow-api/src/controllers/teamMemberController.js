const pool = require('../config/db');

/**
 * Add a user to a team (ADMIN ONLY)
 */
exports.addMember = async (req, res) => {
  const { teamId } = req.params;
  const { userId, role } = req.body;

  if (!userId)
    return res.status(400).json({ message: 'User ID required' });

  try {
    // Check requester role
    const [rows] = await pool.query(
      'SELECT role FROM team_members WHERE team_id = ? AND user_id = ?',
      [teamId, req.user.id]
    );

    if (!rows.length || rows[0].role !== 'admin')
      return res.status(403).json({ message: 'Admin access required' });

    await pool.query(
      'INSERT INTO team_members (team_id, user_id, role) VALUES (?, ?, ?)',
      [teamId, userId, role || 'developer']
    );

    res.status(201).json({ message: 'User added to team' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/**
 * List team members
 */
exports.getMembers = async (req, res) => {
  const { teamId } = req.params;

  try {
    const [members] = await pool.query(
      `SELECT u.id, u.name, u.email, tm.role
       FROM team_members tm
       JOIN users u ON u.id = tm.user_id
       WHERE tm.team_id = ?`,
      [teamId]
    );

    res.json(members);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
