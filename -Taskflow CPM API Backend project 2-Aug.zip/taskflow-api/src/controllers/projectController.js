const pool = require('../config/db');

/**
 * Create a project (Admin or Manager)
 */
exports.createProject = async (req, res) => {
  const { teamId } = req.params;
  const { name, description, parent_project_id, start_date, end_date } = req.body;

  if (!name)
    return res.status(400).json({ message: 'Project name required' });

  try {
    // Check role in team
    const [roles] = await pool.query(
      'SELECT role FROM team_members WHERE team_id = ? AND user_id = ?',
      [teamId, req.user.id]
    );

    if (!roles.length || !['admin', 'manager'].includes(roles[0].role))
      return res.status(403).json({ message: 'Insufficient permissions' });

    const [result] = await pool.query(
      `INSERT INTO projects 
      (team_id, parent_project_id, name, description, start_date, end_date)
      VALUES (?, ?, ?, ?, ?, ?)`,
      [
        teamId,
        parent_project_id || null,
        name,
        description || null,
        start_date || null,
        end_date || null
      ]
    );

    // creator becomes project owner
    await pool.query(
      'INSERT INTO project_members (project_id, user_id, role) VALUES (?, ?, ?)',
      [result.insertId, req.user.id, 'owner']
    );

    res.status(201).json({
      message: 'Project created',
      projectId: result.insertId
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/**
 * List projects for a team (hierarchy-ready)
 */
exports.getProjectsByTeam = async (req, res) => {
  const { teamId } = req.params;

  try {
    const [projects] = await pool.query(
      'SELECT * FROM projects WHERE team_id = ? ORDER BY parent_project_id',
      [teamId]
    );

    res.json(projects);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
