const fileRoutes = require('./routes/fileRoutes');
const commentRoutes = require('./routes/commentRoutes');
const taskRoutes = require('./routes/taskRoutes');
const projectRoutes = require('./routes/projectRoutes');
const teamMemberRoutes = require('./routes/teamMemberRoutes');
const teamRoutes = require('./routes/teamRoutes');
const authRoutes = require('./routes/authRoutes');
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const app = express();

app.use(cors());
app.use(express.json());

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
});

app.use(limiter);

app.get('/', (req, res) => {
  res.json({ message: 'TaskFlow API running' });
});
app.use('/api/v1/auth', authRoutes);
const authMiddleware = require('./middlewares/authMiddleware');

app.get('/api/v1/protected', authMiddleware, (req, res) => {
  res.json({
    message: 'Access granted',
    user: req.user
  });
});
app.use('/api/v1/teams', teamRoutes);
app.use('/api/v1/teams', teamMemberRoutes);
app.use('/api/v1/teams', projectRoutes);
app.use('/api/v1', taskRoutes);
app.use('/api/v1', commentRoutes);
app.use('/api/v1', fileRoutes);

module.exports = app;
