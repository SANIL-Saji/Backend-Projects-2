# TaskFlow API

## Overview
TaskFlow is a collaborative project management backend API designed to help teams manage projects, tasks, timelines, and communication efficiently.

## Tech Stack
- Node.js
- Express.js
- MySQL
- JWT Authentication
- Multer (File Uploads)

## Features
- User authentication and authorization
- Team creation with role-based access
- Hierarchical project management
- Task creation with priorities and dependencies
- Multiple assignees per task
- Threaded comments
- File uploads and attachments

## Setup Instructions
1. Clone the repository
2. Run `npm install`
3. Create a `.env` file and configure database credentials
4. Import SQL schema into MySQL
5. Run `npm run dev`

## API Base URL

## Database Design
- Fully normalized (3NF)
- Uses junction tables for many-to-many relationships
- Enforces referential integrity with foreign keys

## File Uploads
Files are uploaded using Multer and stored locally in `/uploads`.

## Author
TaskFlow Backend API – Project Submission
